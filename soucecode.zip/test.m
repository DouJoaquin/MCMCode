function flag=test(lenchrom,bound,code)
% lenchrom   input 
% bound      input
% code       output
x=code; 
flag=1;
% if (x(1)<0)&&(x(2)<0)&&(x(3)<0)&&(x(1)>bound(1,2))&&(x(2)>bound(2,2))&&(x(3)>bound(3,2))
%     flag=0;
% end     