
%clc
%clear
%
input;
output;


%load data input output


inputnum=5;
hiddennum=10;
outputnum=1;


input_train=input(1:101,:)'
input_test=input(102:103,:)';
output_train=output(1:101)';
output_test=output(102:103)';


[inputn,inputps]=mapminmax(input_train);
[outputn,outputps]=mapminmax(output_train);


net=newff(inputn,outputn,hiddennum);


maxgen=20;                       
sizepop=10;                       
pcross=0.2;                      
pmutation=0.1;                   


numsum=inputnum*hiddennum+hiddennum+hiddennum*outputnum+outputnum;

lenchrom=ones(1,numsum);
bound=[-3*ones(numsum,1) 3*ones(numsum,1)];    

individuals=struct('fitness',zeros(1,sizepop), 'chrom',[]);  
avgfitness=[];                   
bestfitness=[];                     
bestchrom=[];                     

for i=1:sizepop
    
    individuals.chrom(i,:)=Code(lenchrom,bound);   
    x=individuals.chrom(i,:);

    individuals.fitness(i)=fun(x,inputnum,hiddennum,outputnum,net,inputn,outputn);  
end
FitRecord=[];

[bestfitness, bestindex]=min(individuals.fitness);
bestchrom=individuals.chrom(bestindex,:);  
avgfitness=sum(individuals.fitness)/sizepop;

trace=[avgfitness bestfitness];


for i=1:maxgen
    i
    
    individuals=Select(individuals,sizepop); 
    avgfitness=sum(individuals.fitness)/sizepop;
    
    individuals.chrom=Cross(pcross,lenchrom,individuals.chrom,sizepop,bound);
    
    individuals.chrom=Mutation(pmutation,lenchrom,individuals.chrom,sizepop,i,maxgen,bound);
    
    
    for j=1:sizepop
        x=individuals.chrom(j,:); 
        individuals.fitness(j)=fun(x,inputnum,hiddennum,outputnum,net,inputn',outputn);   
    end
    [newbestfitness,newbestindex]=min(individuals.fitness);
    [worestfitness,worestindex]=max(individuals.fitness);
    
    if bestfitness>newbestfitness
        bestfitness=newbestfitness;
        bestchrom=individuals.chrom(newbestindex,:);
    end
    individuals.chrom(worestindex,:)=bestchrom;
    individuals.fitness(worestindex)=bestfitness;
    
    avgfitness=sum(individuals.fitness)/sizepop;
    
    trace=[trace;avgfitness bestfitness];
    FitRecord=[FitRecord;individuals.fitness];
end


figure(1)
[r c]=size(trace);
plot([1:r]',trace(:,2),'b--');
title(['��Ӧ������  ' '��ֹ������' num2str(maxgen)]);
xlabel('��������');ylabel('��Ӧ��');
legend('ƽ����Ӧ��','�����Ӧ��');
disp('��Ӧ��                   ����');

w1=x(1:inputnum*hiddennum);
B1=x(inputnum*hiddennum+1:inputnum*hiddennum+hiddennum);
w2=x(inputnum*hiddennum+hiddennum+1:inputnum*hiddennum+hiddennum+hiddennum*outputnum);
B2=x(inputnum*hiddennum+hiddennum+hiddennum*outputnum+1:inputnum*hiddennum+hiddennum+hiddennum*outputnum+outputnum);

net.iw{1,1}=reshape(w1,hiddennum,inputnum);
net.lw{2,1}=reshape(w2,outputnum,hiddennum);
net.b{1}=reshape(B1,hiddennum,1);
net.b{2}=B2;
net.trainParam.epochs=100;
net.trainParam.lr=0.1;


[net,per2]=train(net,inputn,outputn);
inputn_test=mapminmax('apply',input_test,inputps);
an=sim(net,inputn_test);
test_simu=mapminmax('reverse',an,outputps);
error=test_simu-output_test;

web browser www.matlabsky.com